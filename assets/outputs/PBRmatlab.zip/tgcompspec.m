function [F, S] = tgcompspec(x, doplot)
% function [F, S] = tgcompspec(x, doplot)
% Calculates compsite spectra using the procedure outlined in Thornton &
% Gilden (in press)
%
% IN: 	x--time series vector
%       doplot--if >0, plot composite spectrum of x
% OUT:  F--vector of frequencies
%       S--composite spectrum of x
%       CAREFUL--F and S run backwards (from high to low frequency)

xsz = size(x);
if xsz(2) < xsz(1)
    x = x';
end
N = length(x);
j = 1:(floor(log2(N))-2);
m = 2.^(j+1); % don't take the first one (f=1/N)--T&G throw it away
                              
F = 1./m;
S = zeros(1, length(F));

for j=1:length(F)
    [tempf, spec] = tgavspec(x, m(j), 0);
    S(j) = spec(1)/(N* m(j)); 
end

if doplot
    plot(log10(F), log10(S), '-sr');
    hold on;
    plot(log10(F), log10(F.^-1) + (min(log10(S)) - min(log10(F.^-1))), '--');
    hold off;
end