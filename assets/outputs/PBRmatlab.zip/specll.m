function loglmat = specll(series, covs)
% loglmat = specll(series, model, covs)
% calculate log likelihood of data under specified model, for each point in
% 20 x 20 parameter space
% IN:   series--a time series (vector)
%       covs--matrix of covariance structures (either fBmWcov or armacov)
% OUT:  loglmat--20 x 20 matrix of lnL's

y = zscore(series);
[f, ys] = tgcompspec(y, 0);
for i=1:20
    for j=1:20
        diffvec=ys - covs(i,j).mean;
        loglmat(i, j) = -(length(ys)/2).*log(2*pi) - .5.*log(det(covs(i,j).cov)) -.5*(diffvec * inv(covs(i,j).cov) * diffvec');
    end
end