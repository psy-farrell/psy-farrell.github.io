function [freq, spec] = tgavspec(x, m, doplot)
% function [freq, spec] = tgavspec(x, m, doplot)
% calculates a window-averaged spectrum (Thornton & Gilden, in press) for
% a time series
%
% IN:   x--time series vector
%       m--size of window
%       doplot--if >0, plot window-averaged spectrum of x
% OUT:  freq--vector of frequencies
%       spec--window-averaged spectrum of x

K = (2*length(x)/m)-1;
for i=1:K
    stin = ((i-1)*m/2)+1;
    endin = stin + m-1;
    
    [freq, S] = sspec(x(stin:endin), 1, 0);
    
    if i==1
        spec = S;
    else
        spec = [spec; S];
    end
end

spec=mean(spec, 1);

if doplot
    plot(log10(freq), log10(spec), '-+k');
    hold on;
    plot(log10(freq), log10(freq.^-1) + min(log10(spec))-0.5, '--');
    hold off;
end