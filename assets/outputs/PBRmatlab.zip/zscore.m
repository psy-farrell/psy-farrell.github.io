function y = zscore(x)
% ZSCORE Turn the elements of x into zscores(ie normalise series)
% August, 2005: modified f to use N (rather than N-1) in normalisation

y = x-mean(x);
y = y./std(y, 1);