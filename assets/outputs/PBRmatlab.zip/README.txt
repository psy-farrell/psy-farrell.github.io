This zip file contains code for maximum likelihood estimation for Thornton and Gilden's (in press) spectral classifier. The files contained are:

getspecll.m
-- Function that returns maximum log likelihood estimates for a time series

armacov.mat
fBmWcov.mat
-- Files containing libraries of spectral covariance

tgcompspec.m
tgavspec.m
sspec.m
-- Functions for constructing composite spectra

zscore.m
-- Function returning standardised version of a time series (note: this function uses exact SD, not the unbiased estimate used in R by default)

specll.m
-- low-level function for calculating log-likelihoods across parameter space of both models

fBmW.m
-- function for generating 1/f series. Not needed to run analyses, but useful for generating test series

fracdiff.m
-- call R fracdiff from MATLAB; see below

**********************************************************
Running spectral classifier:

First, load up the covariance libraries (armacov.mat and fBmWcov.mat) into your workspace.


Then call the function "getspecll" thus:

getspecll(tser, armacov, fBmWcov)

where tser is your time series to be analysed. Note that your time series must have a length of 1024. The output is a structure containing the maximum lnL estimates.

**********************************************************
Running the ARFIMA method:

We used the ARFIMA routines in R (contained in the "fracdiff" package) to run our ARFIMA analyses. One way to do this is to run the analyses in R directly (see the R code available from the website where the file you are reading was obtained). In Windows, you can also have a setup in which the R ARFIMA code can be called from MATLAB. You will need to do the following:

1. Install R (from http://cran.r-project.org/)
2. Install the R (D)COM interface (from http://cran.r-project.org/; look under "other"). This allows other programs to make calls to R functions and read/write variables.
3. Install the fracdiff package in R (use the menu system).
4. Download the MATLAB R-link package of Robert Henson, available from:
http://www.mathworks.com/matlabcentral/fileexchange/loadFile.do?objectId=5051&objectType=file
and put it somewhere in your MATLAB path. This set of functions allows one to access R from MATLAB using the (D)COM interface.
5. The file fracdiff.m is a Wrapper functions for calling the R fracdiff function from MATLAB