function [freq, spec] =  sspec (argser, normconst, doplot)
% function [freq, spec] =  sspec (argser, normconst, doplot)
% calculate power spectrum using fft function
% IN:   argser--time series vector
%       normconst--normalisation constant (if below 1, set to
%       length of the series)
%       doplot--if >0, plot the spectrum of the series
% OUT:  freq--a vector of frequencies
%       spec--power spectrum of argser

sizeser = length(argser);
nfft = floor(sizeser/2);

if (normconst <1)
    normconst = sizeser;
end

freq = (1:nfft)./sizeser;

ffk = fft(argser);
ffk = ffk./normconst;
spec = (abs(ffk)).^2;
spec = spec(2:nfft+1); % 1 is f=0 (mean); chuck this out

if doplot
    plot(log10(freq), log10(spec), '-k');
    hold on;
    plot(log10(freq), log10((freq.^-1)) + min(log10(spec)), '--');
    hold off;
end