function y = fracdiff(ser, nar, nma, d)
% ser: time series
% nar: number of AR parameters
% nma: number of MA parameters
% d: if d>=0, fit ARFIMA (d is free), else fit ARMA (d is restricted to
% range between 0 and 10e-8

global R_lInK_hANdle

% Check if a connection exists
if isempty(R_lInK_hANdle)
    openR
end

% uncomment this, or make sure the fracdiff library is loaded up before
% calling
% evalR('library(fracdiff)')

putRdata('kk', ser);

if (d>=0)
    evalR(['y <- fracdiff(t(kk), nar=' num2str(nar) ', nma=' num2str(nma) ')']) %arfima
else
    evalR(['y <- fracdiff(t(kk), nar=' num2str(nar) ', nma=' num2str(nma) ', drange=c(0,.000001))']) %arma
end

y.ll = evalR('y$log.likelihood');
y.ar = evalR('y$ar');
y.ma = -1 * evalR('y$ma');
y.d = evalR('y$d');
y.covar = evalR('y$covariance.dpq');
y.se = evalR('y$stderror.dpq');
y.npar = nar + nma + 2; % one for d, one for the variance

% uncomment this, or close the Rlink manually when you've finished all your analyses
%closeR(R_lInK_hANdle);