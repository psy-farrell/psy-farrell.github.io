function res = getspecll(tser, armacov, fBmWcov)
% Calculate log likelihood of a series under ARMA and fBmW using Thornton &
% Gilden's (in press) method
% IN:   tser--time series vector
%       armacov--covariance structure for ARMA model (contained in
%           armacov.mat)
%       fBmWcov--covariance structure for fBmW model (contained in
%           fBmWcov.mat)
% OUT:  res-- a structure with spectral log likelihood results:
%           .armall--lnL of ARMA model
%           .fBmWll--lnL of fBmW model
%           .lldiff--difference in log likelihoods (fBmWll - armall)
%           .armapar--vector of max lik estimates: [phi theta]
%           .fBmWpar--vector of max lik estimates: [alpha beta]

% use Thornton and Gilden method for some data
phi=linspace(.1, .95, 20);
k = 0:19; theta=(-.0854 .*k) + (.002 * k.^2);
alpha=linspace(.1, 1, 20);
beta=linspace(0,2,20);

log0 = specll(tser, armacov);
[yt, a1] = max(log0);
[res.armall, a2] = max(yt);
log1 = specll(tser, fBmWcov);
[yt, b1] = max(log1);
[res.fBmWll, b2] = max(yt);

res.lldiff = res.fBmWll - res.armall;
res.armapar = [phi(a1(a2)) theta(a2)];
res.fBmWpar = [alpha(b1(b2)) beta(b2)];