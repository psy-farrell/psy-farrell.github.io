specll <- function (series, covs){
	# loglmat = specll(series, model, covs)
	# calculate log likelihood of data under specified model, for each point in
	# 20 x 20 parameter space
	# IN:   series--a time series (vector)
	#       covs--matrix of covariance structures (either fBmWcov or armacov)
	# OUT:  loglmat--20 x 20 matrix of lnL's

	y = zscore(series);
	tspec = tgcompspec(y, 0);
	loglmat = matrix(rep(0,400), ncol=20)
	
	for (i in 1:20){
    		for (j in 1:20){
           	diffvec= tspec$spec - covs$mean[i,j,];
        		loglmat[i, j] = -(length(diffvec)/2)*log(2*pi) - .5*log(det(covs$cov[i,j,,])) -.5*(t(diffvec) %*% solve(covs$cov[i,j,,]) %*% diffvec);
    		}
	}
	ret <- loglmat
}