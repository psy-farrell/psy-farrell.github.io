# Source this file, and it will load up all the relevant functions and data to allow calculation of spectral likelihood

source("tgspec.R")
source("specll.R")
source("fBmW.R")
source("zscore.R")
source("getspecll.R")
source("getarfimall.R")
load("armacov.Rdata")
load("fBmWcov.Rdata")