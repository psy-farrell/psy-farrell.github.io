getspecll <- function(tser, armacov, fBmWcov){

# Calculate log likelihood of a series under ARMA and fBmW using Thornton &
# Gilden's (in press) method
# IN:   tser--time series vector
#       armacov--covariance structure for ARMA model (contained in
#           armacov.Rdata)
#       fBmWcov--covariance structure for fBmW model (contained in
#           fBmWcov.Rdata)
# OUT:  res-- a list with spectral log likelihood results:
#           armall--lnL of ARMA model
#           fBmWll--lnL of fBmW model
#           lldiff--difference in log likelihoods (fBmWll - armall)
#           armapar--vector of max lik estimates: [phi theta]
#           fBmWpar--vector of max lik estimates: [alpha beta]

	alpha = seq(.1, 1, length=20)
	beta = seq(0, 2, length=20);
	phi=seq(.1, .95, length=20);
	k = 0:19; theta=(-.0854 *k) + (.002 * k^2);

	log0 = specll(tser, armacov);
     y <- max.col(t(log0));
     mvals = log0[cbind(y, 1:20)]
     a2 = which.max(mvals)
     a1 = y[a2]
     armall = log0[a1, a2]
            
	log1 = specll(tser, fBmWcov);
     y <- max.col(t(log1));
     mvals = log1[cbind(y, 1:20)]
     b2 = which.max(mvals)
     b1 = y[b2]
     fBmWll = log1[b1, b2]

	armapar=c(phi[a1], theta[a2])
	fBmWpar=c(alpha[b1], beta[b2])	
     
     ret <- list(armall=armall, fBmWll=fBmWll, lldiff=fBmWll-armall, armapar=armapar, fBmWpar=fBmWpar)

}