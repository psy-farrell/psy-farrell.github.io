This zip file contains code for maximum likelihood estimation for Thornton and Gilden's (in press) spectral classifier. The files contained are:

getspecll.R
-- Function that returns maximum log likelihood estimates for a time series

armacov.Rdata
fBmWcov.Rdata
-- Files containing libraries of spectral covariance

tgspec.R
-- Functions for constructing composite spectra

source1f.R
-- Source this script to load all the contained functions and data into your workspace

zscore.R
-- Function returning standardised version of a time series (note: this function uses exact SD, not the unbiased estimate used in R by default)

specll.R
-- low-level function for calculating log-likelihoods across parameter space of both models

fBmW.R
-- function for generating 1/f series. Not needed to run analyses, but useful for generating test series

**********************************************************
Running spectral classifier:

You should only need to run two commands. First, load up the functions and libraries by typing at the prompt:

source("source1f.R")

Then call the function "getspecll" thus:

res <- getspecll(tser, armacov, fBmWcov)

where tser is your time series to be analysed. Note that your time series must have a length of 1024. The variable res will be a list containing the output of the function.

**********************************************************
Running the ARFIMA method:

First, make sure you have installed the "fracdiff" package (on Windows and OS X you can install packages using the GUI). You should then load the fracdiff package by typing

library(fracdiff)

at the prompt. To obtain help on the fracdiff ARFIMA function, type

?fracdiff

at the prompt. To run the ARFIMA analysis, you could run the included script "getarfimall.R" by typing, at the prompt:

res <- getarfimall(tser)

where tser is your time series to be analysed. Your time series can be of any length (though, of course, longer series will take longer to estimate). The variable res will be a list containing the output of "getarfimall"