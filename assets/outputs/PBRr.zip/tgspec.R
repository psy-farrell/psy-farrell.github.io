# This file contains a bunch of functions for constructing a 
# composite spectrum a la Thornton & Gilden (in press). 
# The function to call is tgcompspec.R(which will then call
# the other functions as needed)

tgcompspec <- function(x, doplot){
# Calculates compsite spectra using the procedure outlined in Thornton &
# Gilden (in press)
#
# IN: 	x--time series vector
#       doplot--if >0, plot composite spectrum of x
# OUT:  a list containing:
#		F--vector of frequencies
#        S--composite spectrum of x
#        [CAREFUL: F and S run backwards (from high to low frequency)]

N = length(x);
j = 1:(floor(log2(N))-2);
m = 2^(j+1); # don't take the first one (f=1/N)--TG throw it away
                              
F = 1/m;
S = rep(0, length(F));

for (j in 1:length(F)){
    tspec = tgavspec(x, m[j], 0);
    S[j] = tspec$spec[1]/(N* m[j]); 
}

if (doplot>0){
    plot(log10(F), log10(S), type="l", las=1);
    par(new=T)
    plot(log10(F), log10(m) + min(log10(S)), type="l", lty=2, xlab="", ylab="", axes=FALSE);
}

ret <- list(freq=F, spec=S)    
}

tgavspec <- function (x, m, doplot){
# calculates a window-averaged spectrum
# windows are overlapping, m is the size of segments
# cf Thornton & Gilden PBR

K = floor((2*length(x)/m)-1);
for (i in 1:K){
    stin = ((i-1)*m/2)+1;
    endin = stin + m-1;
    
    tspec = sspec(x[stin:endin], 1, 0);
    
    if (i==1){
        spec = tspec$spec;
    } else {
        spec = cbind(spec,tspec$spec);
    }
}

spec=apply(spec, 1, mean);

freq = tspec$freq


if (doplot>0){
    plot(log10(freq), log10(spec), type="l", las=1);
    par(new=T)
    plot(log10(freq), log10((freq^-1)) + min(log10(spec)), type="l", lty=2, xlab="", ylab="", axes=F);
}

ret <- list(freq=freq, spec=spec)
}

sspec <- function (argser, normconst, doplot){
# spectrum using fft
# normconst is a normalisation constant
# fft is divided by normconst before squared modulus being applied
# if ~normconst>0, series length is used to normalise

if (normconst <1){
    normconst = length(argser);
}

sizeser = length(argser);
nfft = floor(sizeser/2);

freq = (1:nfft)/sizeser;

ffk = fft(argser);
ffk = ffk/normconst;
spec = (abs(ffk))^2;
spec = spec[2:(nfft+1)]; # 1 is f=0 (mean); chuck this out

if (doplot==1){
    plot(log10(freq), log10(spec), type="l", las=1);
    par(new=T)
    plot(log10(freq), log10((freq^-1)) + min(log10(spec)), type="l", lty=2, xlab="", ylab="", axes=F);
}

ret = list(freq=freq, spec=spec)
}