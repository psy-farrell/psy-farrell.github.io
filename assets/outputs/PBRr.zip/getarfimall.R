getarfimall <- function(tser){

# Calculate log likelihood of a series under ARMA and ARFIMA using the fracdiff package
# You will need to make sure the fracdiff package is installed and loaded; see README.txt for details
# IN:   tser--time series vector
# OUT:  res-- a list with ARFIMA log likelihood results:
#           armall--lnL of ARMA model
#           arfimall--lnL of ARFIMA model
#           lldiff--difference in log likelihoods (fBmWll - armall)
#           armapar--vector of max lik estimates: [phi theta]
#           arfimapar--max lik estimate of d


	# fitting ARMA(1,1) actually fits ARFIMA, but with d restricted to be tiny (in range 0 to 10e-8)
	suppressWarnings(y <- fracdiff(tser, 1, 1, drange=c(0, .00000001)));
	armall <- y$log;
	armapar <- c(y$ar, y$ma)
	
	y <- fracdiff(tser, 0, 0);
     arfimall <- y$log;
     arfimapar <- y$d
     
     lldiff <- arfimall - armall
          
     ret <- list(armall=armall, arfimall=arfimall, lldiff=arfimall-armall, armapar=armapar, arfimapar=arfimapar)

}