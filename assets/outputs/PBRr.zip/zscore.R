#############################################
# zscore: give x as z-score with respect to
# distribution with mean xmean and sd xsd
###############################################
zscore <- function(x){
  xmean <- mean(x);
  xl <- length(x);
  xsd <- sqrt(var(x)*((xl-1)/xl)); # this is to have sd exactly=1
   # (otherwise, R by default uses unbiased estimate with n-1 in denominator)
  ret <- (x-xmean)/xsd;
}
