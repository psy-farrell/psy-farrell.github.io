fBmW <- function (liln, alpha, beta)
{
	# generate fBm and then
	# white noise is then added to standardised series
	# see Farrell et al. (submitted) and Thornton & Gilden (in press)
	# IN:   liln--length of desired series
	#       alpha--alpha of fBm
	#       beta--beta of W
	# OUT:  noise--a fBmW time series (vector)N <- liln*2;
	
	N <- liln*2;
	realv <- rep(0, N);
	imagv <- rep(0, N);
	nn <- 2:((N/2)+1);
	mag <- nn^(-alpha/2);
	pha <- 2 * pi * runif(length(nn));
	realv[nn] <- mag * cos(pha);
	imagv[nn] <- mag * sin(pha);
	realv[seq(N, (N/2)+2, -1)] <-  realv[2:(N/2)];
	imagv[seq(N, (N/2)+2, -1)] <- -imagv[2:(N/2)];
	imagv[(N/2)+1] <- 0;
 
	noise <- Re(fft(complex(real=realv, imaginary=imagv), inverse=TRUE));
	noise <- zscore(noise[1:liln]);
	noise <- zscore(noise + beta*rnorm(liln))
}
